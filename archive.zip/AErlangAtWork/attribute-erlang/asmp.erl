-module(asmp).
-compile(export_all).

start() ->
    awoman:init(#{id => w1, gender => w, eyes => blue, hair => red, prefs => #{wealth => poor, body => weak}, partner => null, prior => -1}),
    awoman:init(#{id => w2, gender => w, eyes => blue, hair => dark, prefs => #{wealth => rich, body => strong}, partner => null, prior => -1}),
    awoman:init(#{id => w3, gender => w, eyes => green, hair => red, prefs => #{wealth => rich, body => strong}, partner => null, prior => -1}),
    awoman:init(#{id => w4, gender => w, eyes => green, hair => dark, prefs => #{wealth => rich, body => weak}, partner => null,  prior => -1}),

    aman:init(#{id => m1, gender => m, wealth => rich, body => strong,
		plist => [[{eyes,blue},{hair,red}],[{eyes,blue}],[{hair,red}],[{gender,w}]], refusal => [], partner => null}),
    aman:init(#{id=> m2, gender => m, wealth => rich, body => weak,
		plist => [[{eyes,green},{hair, dark}],[{eyes,green}],[{hair,dark}],[{gender,w}]], refusal => [], partner => null}),
    aman:init(#{id=> m3, gender => m, wealth => poor, body => strong,
		plist => [[{eyes,green}, {hair, red}],[{eyes,green}],[{hair,red}],[{gender,w}]], refusal => [], partner => null}),
    aman:init(#{id=> m4, gender => m, wealth => poor, body => weak,
		plist => [[{eyes,blue},{hair,red}],[{eyes,blue}],[{hair,red}],[{gender,w}]], refusal => [], partner => null}).
