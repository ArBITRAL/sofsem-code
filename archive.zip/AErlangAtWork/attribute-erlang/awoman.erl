-module(awoman).
-compile(export_all).

% using map to store environment
init(Env) ->
    spawn(fun() ->
		  start(Env) end).

start(Env) ->
    %% register itself
    global:register_name(maps:get(id,Env),self()),
    io:format("Woman <~p> ~p start!~n",[self(),maps:get(id,Env)]),
    timer:sleep(1000),
    woman(Env).

woman(Env) ->
    Id = maps:get(id,Env),
    Partner = maps:get(partner,Env),
    L = maps:get(prefs,Env),
    Prior = maps:get(prior,Env),
    io:format("Woman ~p has current partner ~p ~n",[Id,Partner]),
    Msg = a_receive([],Env),
    case Msg of
	{propose,M,W,B} ->
	    case bof(L, Prior, W, B) of
		{true,New} ->
		    a_send([{id,Partner}],{no,Id},Env),
		    a_send([{id,M}],{yes,Id},Env),
		    NEnv = Env#{partner:=M,prior:=New},
		    woman(NEnv);
		{false,_} ->
		    a_send([{id,M}],{no,Id},Env),
		    woman(Env)
	    end
    end.

bof(L, Param, W, B) ->
  #{wealth := X, body := Y} = L,
  Score = case {X,Y} of
      {W,B} -> 3;
      {W,_} -> 2;
      {_,B} -> 1;
      _Other ->0
  end,
  {Score >= Param,Score}.

%% This implementation is very specific for the SM problem.
%% It considers only predicate in form of tuplelists [{a1,v1},{a2,v2},...]
%% And only concern logical connective AND between predicates.

a_send(Ps,Msg,Envs) ->
    %% broadcast
    L = global:registered_names(),
    lists:foreach(fun(Name) -> global:send(Name, {Ps,Msg,Envs}) end, L).

a_receive(Pr,Envr) ->
    receive
	{Ps,Msg,Envs} ->
	    case check(Ps,Envr) andalso check(Pr,Envs) of
		true ->
		    Msg;
		false ->
		    a_receive(Pr,Envr)
	    end
    end.

check(L2,Env) ->
    L1 = maps:to_list(Env),
    length(L1) - length(L2) == length(lists:subtract(L1,L2)).
