-module(aman).
-compile(export_all).

init(Env) ->
    spawn(fun() ->
		  start(Env) end).
start(Env) ->
    global:register_name(maps:get(id,Env),self()),
    io:format("Man <~p> ~p start!~n",[self(),maps:get(id,Env)]),
    timer:sleep(1000),
    man(Env).

man(Env) ->
    Id = maps:get(id,Env),
    Body = maps:get(body,Env),
    Wealth = maps:get(wealth,Env),
    [H|T] = maps:get(plist,Env),
    Refusal = maps:get(refusal,Env),
    io:format("Man ~p proposes with redicate ~p~n",[Id,H]),
    a_send(Refusal,H,{propose, Id, Wealth, Body},Env),
    Msg = a_receive([],Env),
    case Msg of
	{yes, Wid} ->
	    NEnv = Env#{plist:=T,partner:=Wid},
	    Msg1 = a_receive([],Env),
	    case Msg1 of
		{no, Wid} ->
		    man(NEnv#{plist:=T,partner:=null,refusal:=Refusal++[Wid]})
	    end;
	{no,Wid} ->
	    man(Env#{plist:=T,partner:=null,refusal:=Refusal++[Wid]})
    end.

%% This implementation is very specific for the SM problem.
%% It considers only predicate in form of tuplelists [{a1,v1},{a2,v2},...]
%% and only concern logical connective AND between predicates.

a_send(Refusal,Ps,Msg,Envs) ->
    %% broadcast
    All = global:registered_names(),
    L = lists:subtract(All,Refusal),
    %io:format("List of valid receivers ~p~n",[L]),
    lists:foreach(fun(Name) -> global:send(Name, {Ps,Msg,Envs}) end, L).

a_receive(Pr,Envr) ->
    receive
	{Ps,Msg,Envs} ->
	    case check(Ps,Envr) andalso check(Pr,Envs) of
		true ->
		    Msg;
		false ->
		    a_receive(Pr,Envr)
	    end
    end.

check(L2,Env) ->
    L1 = maps:to_list(Env),
    length(L1) - length(L2) == length(lists:subtract(L1,L2)).
