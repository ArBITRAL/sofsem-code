-module(asmp).
-compile(export_all).

start() ->
    aerl:start(broadcast),

    awoman:init(#{id => w1, gender => w, eyes => blue, hair => red, prefs => #{wealth => poor, body => weak}, partner => null, prior => -1}),
    awoman:init(#{id => w2, gender => w, eyes => blue, hair => dark, prefs => #{wealth => rich, body => strong}, partner => null, param => -3,  prior => -1, params => {-1, -1}}),
    awoman:init(#{id => w3, gender => w, eyes => green, hair => red, prefs => #{wealth => rich, body => strong}, partner => null, param => -3, prior => -1, params => {-1, -1}}),
    awoman:init(#{id => w4, gender => w, eyes => green, hair => dark, prefs => #{wealth => rich, body => weak}, partner => null, param => -3, prior => -1, params => {-1, -1}}),

    aman:init(#{id=> m1, gender => m, wealth => rich, body => strong, predicate => ["eyes = this.feyes and hair = this.fhair", "eyes = this.feyes", "hair = this.fhair", "gender = woman"],feyes => blue, fhair => red, refusal => [], partner => null}),
    aman:init(#{id=> m2, gender => m, wealth => rich, body => weak, predicate => ["eyes = this.feyes and hair = this.fhair", "eyes = this.feyes", "hair = this.fhair", "gender = woman"],feyes => green, fhair => dark, refusal => [] , partner => null}),
    aman:init(#{id=> m3, gender => m, wealth => poor, body => strong,predicate => ["eyes = this.feyes and hair = this.fhair", "eyes = this.feyes", "hair = this.fhair", "gender = woman"], feyes => green, fhair => red, refusal => [], partner => null}),
    aman:init(#{id=> m4, gender => m, wealth => poor, body => weak, feyes => blue, fhair => red, predicate => ["eyes = this.feyes and hair = this.fhair", "eyes = this.feyes", "hair = this.fhair", "gender = woman"],refusal => [], partner => null}).
