-module(aman).
-compile({parse_transform,aerl_trans}).
-compile(export_all).

% AbC code for Man
% M := [partner:=top[preference];preference:=preference.tail](propose,this.mid)@(wid=partner).(x=invalid)(x).M

init(Env) ->
    spawn(fun() ->
		  start(Env) end).
start(Env) ->
    %% Register itself
    aerl:register(self(),Env),
    io:format("Man <~p> ~p start!~n",[self(),aerl:getAtt(id)]),
    man().

man() ->
    [Id,Body,Wealth,[Ps]]=aerl:getAtts([id,body,wealth,predicate]),
    to(Ps) ! {propose, Id, Wealth, Body},
    from("tt"),
    receive
	{yes, Wid} ->
	    aerl:setAtt(partner,Wid),
	    from("tt"),
	    receive
		{no, Wid} ->
		    aerl:setAtt(partner,null)
	    end;
	{no,_} ->
	    aerl:setAtt(partner,null)
    end,
    io:format("Man ~p has partner ~p ~n",[Id,aerl:getAtt(partner)]).
